from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render


def login_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard:dashboard")

    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "")
        user = authenticate(request, username=username, password=password)

        if user is None:
            messages.error(request, "Invalid username or password.")
        elif not (user.is_staff or user.is_superuser):
            messages.error(request, "This account does not have admin access.")
        else:
            login(request, user)
            return redirect("dashboard:dashboard")

    return render(request, "dashboard/login.html")


@login_required
def dashboard_view(request):
    return render(request, "dashboard/dashboard.html")


def logout_view(request):
    logout(request)
    return redirect("dashboard:login")
