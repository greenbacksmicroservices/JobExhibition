﻿const toggle = document.getElementById('menuToggle');
const overlay = document.getElementById('sidebarOverlay');

if (toggle) {
  toggle.addEventListener('click', () => {
    document.body.classList.toggle('sidebar-open');
  });
}

if (overlay) {
  overlay.addEventListener('click', () => {
    document.body.classList.remove('sidebar-open');
  });
}

